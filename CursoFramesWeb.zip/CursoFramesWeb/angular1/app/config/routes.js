angular.module('primeiraApp').config([
  '$stateProvider', //ui-router que tem la dentro que serve para fazer as nossas navegacoes
  '$urlRouterProvider', //nomes padroes
  function($stateProvider, $urlRouterProvider) { //funcao com os dois objetos
    $stateProvider.state('dashboard', {
      url: "/dashboard", //um estado, estado dashboard
      templateUrl: "dashboard/dashboard.html" //carregar o template, ai vai carregar la no index ui view
    }).state('billingCycle', {
      url: "/billingCycles?page", //mais um estado
      templateUrl: "billingCycle/tabs.html" //esse estado chama um html
    })

    $urlRouterProvider.otherwise('/dashboard') //caso no link ele nao conheça ninguem volta para o dashboard
}])
