angular.module('primeiraApp').component('contentHeader', { //nome do componente que sera uma session
   bindings: { //recebendo os parametros como string, bindings sao parametros
      name: '@', //uso @ porque o nome nunca sera alterado
      small: '@',
   },
   template: `
      <section class="content-header">
        <h1>{{ $ctrl.name }} <small>{{ $ctrl.small }}</small></h1>
      </section>
   ` //ctrl para colocar padrao essa "session"
});

