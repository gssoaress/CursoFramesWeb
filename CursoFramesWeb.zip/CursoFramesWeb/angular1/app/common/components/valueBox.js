angular.module('primeiraApp').component('valueBox', {
  bindings: {
    grid: '@', //col bla bla
    colorClass: '@', // a cor de fundo da div, bg-green ex
    value: '@', //o valor em reais
    text: '@', // um texto o exemplo o <p>
    iconClass: '@', // o icone da div
  },
  controller: [
    'gridSystem',
    function(gridSystem) {
      this.$onInit = () => this.gridClasses = gridSystem.toCssClasses(this.grid) //esse oninit faz o controller ser inicializado apos os bindings
    }
  ],
  template: `
  <div class="{{ $ctrl.gridClasses }}">
    <div class="small-box {{ $ctrl.colorClass }}">
      <div class="inner">
        <h3>{{ $ctrl.value }}</h3>
        <p>{{ $ctrl.text }}</p>
      </div>
      <div class="icon">
        <i class="{{ $ctrl.iconClass }}"></i>
      </div>
    </div>
  </div>
  `
  //so mudo os parametros que eu irei pegar no bindings
});
