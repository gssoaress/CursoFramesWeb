angular.module('primeiraApp').factory('gridSystem', [ function() { //nome da factory grid

  function toCssClasses(numbers) { //pega os numeros como string
    const cols = numbers ? numbers.split(' ') : [] //constante que pega resultado, se numbers tiver indefinido ele vai retornar um vazio
    let classes = '' //uma classe vazia

    if(cols[0]) classes += `col-xs-${cols[0]}` //se eu passar o 3 no parametro , vai fica col-md-3
    if(cols[1]) classes += ` col-sm-${cols[1]}`
    if(cols[2]) classes += ` col-md-${cols[2]}`
    if(cols[3]) classes += ` col-lg-${cols[3]}`

    return classes
  }

  return { toCssClasses }
}])
