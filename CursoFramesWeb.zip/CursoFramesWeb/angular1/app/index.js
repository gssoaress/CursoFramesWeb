angular.module('primeiraApp', [
  'ngAnimate',
  'ui.router',
  'toastr'
])
 //o nome e igual ao ng-app.... aqui to dizendo as dependencias dela