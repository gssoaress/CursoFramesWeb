const _ = require('lodash')
const BillingCycle= require('./billingCycle')

BillingCycle.methods(['get', 'post' , 'put', 'delete']) //o node magica , vai criar nossa api em cima dos metodos do http.. recee um array de metodos
BillingCycle.updateOptions({new:true , runValidators: true}) // sempre que da o send o objeto novo vai de primeira, e fazer a validação dos obrigatorios

//get-> obtem informacao de um ciclo de pagamento
//post->inserir novo ciclo de pagamento
//put-> alterar um ciclo de pagamento
//delete-> apagar um ciclo de pagamento

BillingCycle.route('count', function(req, res, next) {
  BillingCycle.count(function(error, value) {
    if(error) {
      res.status(500).json({errors: [error]})
    } else {
      res.json({value})
    }
  })
})

module.exports = BillingCycle