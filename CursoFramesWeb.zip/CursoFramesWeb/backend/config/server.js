const port = 3052


const bodyParser= require('body-parser') // ele é um middware, ajuda a fazer o parser da requisicao 

const express = require('express')

const server = express()

const allowCors = require('./cors')

server.use(bodyParser.urlencoded({ extended: true })) //urlencoded formato de dados quando vai fazer um formulario e manda as informacoes .. vai via get.. o bodyparser ele se vira pra interpretar

server.use(bodyParser.json()) // outro middware, se for um json o body vai interpretar e vai trasnformar o json em objeto

server.use(allowCors)

server.listen(port, function(){
	console.log(`BACKEND is running on port ${port}.`) //interpolacao da variavel e imprime no console
}) 

module.exports = server